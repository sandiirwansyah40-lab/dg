# SANZ DIGITAL - Panel Pterodactyl & Script Bot Store

## Deskripsi
Website order otomatis Panel Pterodactyl dan Script Bot Telegram dengan sistem pembayaran QRIS via Pakasir Payment Gateway.

## Fitur Utama

### Untuk Guest (Tanpa Login)
- **Order Panel Pterodactyl** - Pilih RAM 1GB-16GB, pilih Egg (js/py), isi data, bayar QRIS
- **Order Script Bot** - Pilih dari katalog, bayar QRIS
- Data panel/script dikirim ke email setelah pembayaran

### Untuk Member (Login)
- **Riwayat Transaksi** - Semua transaksi tercatat
- **Perpanjang Panel** - Perpanjang masa aktif sebelum expired

### Untuk Admin (Login Terpisah)
- **Kelola Harga Panel** - Ubah harga per-GB
- **Kelola Script** - Tambah/edit/hapus script bot
- **Kelola Users** - Lihat semua member
- **Kelola Orders** - Lihat semua order (guest + member)
- **Konfigurasi Pakasir** - API Key dan Project Slug
- **Konfigurasi Pterodactyl** - URL, API Key, Node ID
- **Statistik** - Grafik transaksi

## Struktur File
```
sanz_digital.html  - Website utama (single file)
api.php            - Backend PHP
index.html         - Copy dari sanz_digital.html
database.sql       - Schema MySQL
README.md          - Dokumentasi ini
```

## Cara Install

### 1. Database
```bash
mysql -u root -p < database.sql
```

### 2. Konfigurasi api.php
Edit file `api.php` dan ganti:
```php
$DB_HOST = 'localhost';
$DB_NAME = 'sanz_digital';
$DB_USER = 'root';
$DB_PASS = 'password_anda';

$PAKASIR_PROJECT = 'slug-project-anda';
$PAKASIR_API_KEY = 'api-key-anda';

$PTERO_URL = 'https://sanzszptro.rxpedia.web.id';
$PTERO_API_KEY = 'ptlc_api-key-anda';
```

### 3. Upload ke Hosting
Upload semua file ke folder public_html hosting Anda.

### 4. Setup Webhook Pakasir
Di dashboard Pakasir, set webhook URL ke:
```
https://website-anda.com/api.php?action=webhook
```

### 5. Setup Cron Job (Auto Delete Expired)
Tambahkan cron job setiap hari:
```bash
0 0 * * * curl https://website-anda.com/api.php?action=cleanup
```

## Konfigurasi Pterodactyl

### API Key
1. Login ke panel Pterodactyl Anda
2. Go to Admin > Application API
3. Create new key dengan permissions:
   - Servers (Read & Write)
   - Users (Read & Write)
   - Nests (Read)

### Nest & Egg (Panel Anda)
| Nest ID | Name | Egg ID | Type |
|---------|------|--------|------|
| 5 | js | 5 | Node.js |
| 6 | py | 6 | Python |

**TES WEB (Nest 7) sudah dihapus dari website.**

## Harga Default Panel
| RAM | Harga/Bulan |
|-----|-------------|
| 1GB | Rp 7,000 |
| 2GB | Rp 14,000 |
| 3GB | Rp 21,000 |
| 4GB | Rp 28,000 |
| 5GB | Rp 35,000 |
| 6GB | Rp 42,000 |
| 8GB | Rp 56,000 |
| 10GB | Rp 70,000 |
| 12GB | Rp 84,000 |
| 16GB | Rp 112,000 |

## Default Admin Login
- **Username:** `admin`
- **Password:** `sanzdigital123`

> **PENTING:** Ganti password admin setelah pertama kali login!

## Script Bot Default
1. Bot Telegram Multi Fungsi - Rp 150,000
2. Bot VPN Manager - Rp 200,000
3. Bot Store Digital - Rp 250,000
4. Bot Panel Pterodactyl - Rp 300,000
5. Bot Musik Discord - Rp 180,000
6. Bot WhatsApp Automation - Rp 220,000

## Catatan Penting
- Panel otomatis expired setelah 30 hari
- Guest bisa order tanpa login (hanya perlu email & WA)
- Member login untuk riwayat & perpanjang panel
- Admin login terpisah di sidebar bawah
- Data disimpan di localStorage (demo) / MySQL (production)

## Kontak
- Telegram: @CsSanzDigital
- Live Chat: Tersedia di website
