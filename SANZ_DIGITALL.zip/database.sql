-- SANZ DIGITAL - Database Schema
-- Run this in your MySQL database first

CREATE DATABASE IF NOT EXISTS sanz_digital CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sanz_digital;

-- Users table (for members)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    token VARCHAR(64) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Orders table
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id VARCHAR(50) NOT NULL UNIQUE,
    type ENUM('panel', 'script', 'perpanjang') NOT NULL,
    detail TEXT,
    price INT NOT NULL,
    user_email VARCHAR(100) DEFAULT 'guest',
    user_phone VARCHAR(20) DEFAULT '',
    hostname VARCHAR(100) DEFAULT '',
    username VARCHAR(100) DEFAULT '',
    ram INT DEFAULT 1,
    egg VARCHAR(20) DEFAULT 'js',
    nest_id INT DEFAULT 5,
    egg_id INT DEFAULT 5,
    ptero_server_id INT DEFAULT NULL,
    ptero_server_uuid VARCHAR(50) DEFAULT NULL,
    status ENUM('pending', 'paid', 'completed', 'expired', 'cancelled') DEFAULT 'pending',
    paid_at TIMESTAMP NULL,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Panels table (active panels)
CREATE TABLE panels (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id VARCHAR(50),
    hostname VARCHAR(100),
    ram INT,
    egg VARCHAR(20),
    nest_id INT,
    egg_id INT,
    ptero_server_id INT,
    ptero_server_uuid VARCHAR(50),
    user_email VARCHAR(100),
    status ENUM('active', 'suspended', 'expired') DEFAULT 'active',
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Scripts catalog (managed by admin)
CREATE TABLE scripts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    price INT NOT NULL,
    description TEXT,
    icon VARCHAR(50) DEFAULT 'fas fa-robot',
    features TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin (optional - or use hardcoded in PHP)
-- INSERT INTO users (name, email, password, role) VALUES 
-- ('Admin', 'admin@sanzdigital.com', '$2y$10$YourHashedPasswordHere', 'admin');
