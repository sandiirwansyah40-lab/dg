<?php
// ============================================
// SANZ DIGITAL - Backend API (PHP)
// Compatible with Pterodactyl nests:
//   Nest 5 = js (Node.js)
//   Nest 6 = py (Python)
// ============================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Konfigurasi Database
$DB_HOST = 'localhost';
$DB_NAME = 'sanz_digital';
$DB_USER = 'root';
$DB_PASS = '';

// Konfigurasi Pakasir
$PAKASIR_PROJECT = 'your-project-slug';
$PAKASIR_API_KEY = 'your-api-key';

// Konfigurasi Pterodactyl
$PTERO_URL = 'https://sanzszptro.rxpedia.web.id';  // GANTI DENGAN URL PANEL ANDA
$PTERO_API_KEY = 'ptlc_your_api_key_here';         // GANTI DENGAN API KEY ANDA

// Nest & Egg mapping (sesuai panel Anda)
$NEST_MAP = [
    'js' => ['nest_id' => 5, 'egg_id' => 5, 'docker' => 'ghcr.io/pterodactyl/yolks:nodejs_18', 'startup' => 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z {{NODE_PACKAGES}} ]]; then npm install {{NODE_PACKAGES}}; fi; if [[ -f /home/container/package.json ]]; then npm start; else node /home/container/{{JS_FILE}}; fi'],
    'py' => ['nest_id' => 6, 'egg_id' => 6, 'docker' => 'ghcr.io/pterodactyl/yolks:python_3.11', 'startup' => 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z {{PY_PACKAGES}} ]]; then pip install -U --prefix .local {{PY_PACKAGES}}; fi; if [[ -f /home/container/requirements.txt ]]; then pip install -U --prefix .local -r requirements.txt; fi; {{PY_FILE}}']
];

// Koneksi Database
try {
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
}

$action = $_GET['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true);

switch($action) {

    // ===== CREATE PAKASIR PAYMENT =====
    case 'create_payment':
        $order_id = $input['order_id'] ?? '';
        $amount = $input['amount'] ?? 0;
        $method = $input['method'] ?? 'qris';

        $ch = curl_init("https://app.pakasir.com/api/transactioncreate/$method");
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            'project' => $PAKASIR_PROJECT,
            'order_id' => $order_id,
            'amount' => $amount,
            'api_key' => $PAKASIR_API_KEY
        ]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        echo $response;
        break;

    // ===== CHECK PAYMENT STATUS =====
    case 'check_payment':
        $order_id = $_GET['order_id'] ?? '';
        $amount = $_GET['amount'] ?? 0;

        $ch = curl_init("https://app.pakasir.com/api/transactioncheck/$order_id/$amount");
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        echo $response;
        break;

    // ===== WEBHOOK PAKASIR =====
    case 'webhook':
        $data = json_decode(file_get_contents('php://input'), true);

        if ($data['status'] === 'completed' || $data['status'] === 'success') {
            $order_id = $data['order_id'] ?? '';

            // Get order details from database
            $stmt = $pdo->prepare("SELECT * FROM orders WHERE order_id = ?");
            $stmt->execute([$order_id]);
            $order = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($order && $order['type'] === 'panel') {
                // Create Pterodactyl server
                $result = createPteroServer($order, $PTERO_URL, $PTERO_API_KEY, $NEST_MAP);

                // Update order with server details
                $stmt = $pdo->prepare("UPDATE orders SET status = 'completed', ptero_server_id = ?, ptero_server_uuid = ?, paid_at = NOW() WHERE order_id = ?");
                $stmt->execute([
                    $result['server_id'] ?? null,
                    $result['server_uuid'] ?? null,
                    $order_id
                ]);

                // Send email notification (implement with PHPMailer)
                // sendOrderEmail($order['email'], $result);
            } else {
                // For script orders
                $stmt = $pdo->prepare("UPDATE orders SET status = 'completed', paid_at = NOW() WHERE order_id = ?");
                $stmt->execute([$order_id]);
            }
        }

        echo json_encode(['status' => 'ok', 'received' => true]);
        break;

    // ===== CREATE PTERODACTYL SERVER (Manual Trigger) =====
    case 'create_server':
        $order_id = $input['order_id'] ?? '';

        $stmt = $pdo->prepare("SELECT * FROM orders WHERE order_id = ?");
        $stmt->execute([$order_id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$order) {
            echo json_encode(['success' => false, 'message' => 'Order not found']);
            break;
        }

        $result = createPteroServer($order, $PTERO_URL, $PTERO_API_KEY, $NEST_MAP);
        echo json_encode($result);
        break;

    // ===== SAVE ORDER (Called from frontend after payment) =====
    case 'save_order':
        $order_id = $input['order_id'] ?? '';
        $type = $input['type'] ?? 'panel';
        $detail = $input['detail'] ?? '';
        $price = $input['price'] ?? 0;
        $user_email = $input['user_email'] ?? 'guest';
        $user_phone = $input['user_phone'] ?? '';
        $hostname = $input['hostname'] ?? '';
        $username = $input['username'] ?? '';
        $ram = $input['ram'] ?? 1;
        $egg = $input['egg'] ?? 'js';
        $nest_id = $input['nest_id'] ?? 5;
        $egg_id = $input['egg_id'] ?? 5;

        try {
            $stmt = $pdo->prepare("INSERT INTO orders (order_id, type, detail, price, user_email, user_phone, hostname, username, ram, egg, nest_id, egg_id, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())");
            $stmt->execute([$order_id, $type, $detail, $price, $user_email, $user_phone, $hostname, $username, $ram, $egg, $nest_id, $egg_id]);

            echo json_encode(['success' => true, 'message' => 'Order saved']);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    // ===== DELETE EXPIRED PANELS =====
    case 'cleanup':
        $stmt = $pdo->prepare("SELECT * FROM orders WHERE type = 'panel' AND status = 'completed' AND expires_at < NOW()");
        $stmt->execute();
        $expired = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $deleted = 0;
        foreach ($expired as $order) {
            if ($order['ptero_server_id']) {
                deletePteroServer($order['ptero_server_id'], $PTERO_URL, $PTERO_API_KEY);
                $deleted++;
            }

            $stmt = $pdo->prepare("UPDATE orders SET status = 'expired' WHERE id = ?");
            $stmt->execute([$order['id']]);
        }

        echo json_encode(['deleted' => $deleted, 'expired_count' => count($expired)]);
        break;

    // ===== USER AUTH =====
    case 'register':
        $name = $input['name'] ?? '';
        $email = $input['email'] ?? '';
        $password = password_hash($input['password'] ?? '', PASSWORD_BCRYPT);

        try {
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role, created_at) VALUES (?, ?, ?, 'user', NOW())");
            $stmt->execute([$name, $email, $password]);
            echo json_encode(['success' => true, 'message' => 'Registration successful']);
        } catch(PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Email already exists']);
        }
        break;

    case 'login':
        $email = $input['email'] ?? '';
        $password = $input['password'] ?? '';

        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $token = bin2hex(random_bytes(32));
            $stmt = $pdo->prepare("UPDATE users SET token = ? WHERE id = ?");
            $stmt->execute([$token, $user['id']]);

            unset($user['password']);
            echo json_encode(['success' => true, 'token' => $token, 'user' => $user]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid credentials']);
        }
        break;

    // ===== GET ALL ORDERS (Admin) =====
    case 'get_orders':
        $stmt = $pdo->query("SELECT * FROM orders ORDER BY created_at DESC");
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'orders' => $orders]);
        break;

    // ===== GET ALL USERS (Admin) =====
    case 'get_users':
        $stmt = $pdo->query("SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC");
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'users' => $users]);
        break;

    default:
        echo json_encode(['error' => 'Invalid action']);
}

// Helper: Create Pterodactyl Server
function createPteroServer($order, $pteroUrl, $apiKey, $nestMap) {
    $egg = $order['egg'] ?? 'js';
    $nestConfig = $nestMap[$egg] ?? $nestMap['js'];

    // Step 1: Create or get user
    $userData = [
        'email' => $order['user_email'] ?? 'guest@' . $order['order_id'] . '.local',
        'username' => $order['username'] ?? 'user_' . substr($order['order_id'], -6),
        'first_name' => $order['username'] ?? 'User',
        'last_name' => 'SANZ',
        'password' => bin2hex(random_bytes(8))
    ];

    $ch = curl_init("$pteroUrl/api/application/users");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($userData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $apiKey,
        'Content-Type: application/json',
        'Accept: Application/vnd.pterodactyl.v1+json'
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $userResponse = curl_exec($ch);
    $userResult = json_decode($userResponse, true);
    curl_close($ch);

    $userId = $userResult['attributes']['id'] ?? null;

    // If user already exists, try to get existing user
    if (!$userId && isset($userResult['errors'])) {
        $ch = curl_init("$pteroUrl/api/application/users?filter[email]=" . urlencode($userData['email']));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $apiKey,
            'Accept: Application/vnd.pterodactyl.v1+json'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $existing = json_decode(curl_exec($ch), true);
        curl_close($ch);

        if (!empty($existing['data'])) {
            $userId = $existing['data'][0]['attributes']['id'];
        }
    }

    if (!$userId) {
        return ['success' => false, 'message' => 'Failed to create/get user', 'error' => $userResult];
    }

    // Step 2: Create server
    $serverData = [
        'name' => $order['hostname'] ?? 'Server',
        'user' => (int)$userId,
        'egg' => (int)$nestConfig['egg_id'],
        'docker_image' => $nestConfig['docker'],
        'startup' => $nestConfig['startup'],
        'environment' => [
            'SERVER_AUTOUPDATE' => '1',
            'JS_FILE' => 'index.js',
            'NODE_PACKAGES' => '',
            'PY_FILE' => 'python main.py',
            'PY_PACKAGES' => '',
            'AUTO_UPDATE' => '0'
        ],
        'limits' => [
            'memory' => (int)$order['ram'] * 1024,
            'swap' => 0,
            'disk' => (int)$order['ram'] * 2048,
            'io' => 500,
            'cpu' => (int)$order['ram'] * 25
        ],
        'feature_limits' => [
            'databases' => 1,
            'allocations' => 1,
            'backups' => 1
        ],
        'allocation' => [
            'default' => 1
        ],
        'start_on_completion' => true
    ];

    $ch = curl_init("$pteroUrl/api/application/servers");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($serverData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $apiKey,
        'Content-Type: application/json',
        'Accept: Application/vnd.pterodactyl.v1+json'
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $result = json_decode($response, true);

    if ($httpCode === 201 || $httpCode === 200) {
        return [
            'success' => true,
            'server_id' => $result['attributes']['id'] ?? null,
            'server_uuid' => $result['attributes']['uuid'] ?? null,
            'server_name' => $result['attributes']['name'] ?? null,
            'user_id' => $userId,
            'nest_id' => $nestConfig['nest_id'],
            'egg_id' => $nestConfig['egg_id']
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Failed to create server',
            'http_code' => $httpCode,
            'error' => $result
        ];
    }
}

function deletePteroServer($serverId, $pteroUrl, $apiKey) {
    $ch = curl_init("$pteroUrl/api/application/servers/$serverId");
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $apiKey,
        'Accept: Application/vnd.pterodactyl.v1+json'
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}
?>
